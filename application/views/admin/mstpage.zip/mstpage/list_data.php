<?php
  $no=1;
  foreach ($dataEcommerce->result() as $ecommerce) {
    $tamp=$ecommerce->gambar_ecommerce;
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $ecommerce->nama_ecommerce; ?></td>
      <td><?php echo $ecommerce->link_ecommerce; ?></td>
      <!-- <td><?php echo base_url(); ?>assets/img/ecommerce/<?php echo $tamp; ?></td> -->
      <td>
        <img class="profile-user-img img-responsive img-square" src="<?php
            if($tamp == ''){
          echo base_url('assets/img/not.png');
          // echo file_exists('assets/img/not.png');
        }
          else
          {
            echo $this->config->item('base_url'); ?>assets/frontend/img/ecommerce/<?php echo $tamp;
            
          }
         ?>" alt="User profile picture">
      </td> 
      
      <td class="text-center" style="min-width:270px;">
        <a href="<?php echo base_url() ?>ecommerce/update/<?php echo $ecommerce->id_ecommerce ?>">

          <button class="btn btn-warning">
            <input type="hidden" name="id_ecommerce" value="<?php echo $ecommerce->id_ecommerce ?>">
            <i class="glyphicon glyphicon-repeat"></i> Update
          </button>
        </a>
        
          <button class="btn btn-danger konfirmasiHapus-ecommerce" data-id="<?php echo $ecommerce->id_ecommerce; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Delete</button>
        
      </td>
    </tr>
    <?php
    $no++;
  }
?>
