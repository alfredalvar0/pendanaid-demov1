<div class="content-wrapper">
  <div class=" col-md-12 well">
    <div class="form-msg"></div>
    <h3 style="display:block; text-align:center;">Update Data Ecommerce</h3>

    <form method="POST" enctype="multipart/form-data" class="form-horizontal" action="<?php echo base_url() ?>Ecommerce/prosesUpdate">
      <input type="hidden" name="id_ecommerce" value="<?php echo $dataEcommerce->id_ecommerce ?>">
      <div class="box-body">
        <!-- Nama Ecommerce -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Nama Ecommerce</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Nama Ecommerce" name="nama_ecommerce" aria-describedby="sizing-addon2" value="<?php echo $dataEcommerce->nama_ecommerce ?>">
          </div>
        </div>

        <!-- Link Ecommerce -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Link Ecommerce</label>

          <div class="col-sm-10">
            <input type="text" id="validasi" class="form-control" placeholder="Link Ecommerce" name="link_ecommerce" aria-describedby="sizing-addon2" value="<?php echo $dataEcommerce->link_ecommerce ?>" autocomplete="off">
          </div>
        </div>

        <!-- Foto Artikel -->
        <div class="form-group">
          <label for="inputPassword3" class="col-sm-2 control-label">Gambar Ecommerce</label>

          <div class="col-sm-10">
            <input type="file" class="form-control" placeholder="Foto" name="gambar_ecommerce" aria-describedby="sizing-addon2" value="<?php echo $dataEcommerce->gambar_ecommerce ?>">
          </div>
        </div>

      </div>

      <div class="form-group">
        <div class="col-md-3">
          
        </div>

        <div class="col-md-3">
            <button type="submit" class="form-control btn btn-primary"> <i class="glyphicon glyphicon-ok"></i> Update Data</button>
        </div>
        
        <div class="col-md-3">
          <a href="<?php echo base_url() ?>Ecommerce" class="form-control btn btn-danger">
            <i class="glyphicon glyphicon-remove"></i> Kembali
          </a>
        </div>

        <div class="col-md-3">
          
        </div>
    
      </div>
    </form>
    
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function(){
  $('#validasi').keyup(function() {
      if (this.value.match(/[^0-9A-Za-z-\/.@:%_.\/+~#=]/g)) {
          this.value = this.value.replace(/[^0-9A-Za-z-\/.@:%_.\/+~#=]/g, '');
      }
        
        // console.log(this.value);
        
    });
  });
</script>