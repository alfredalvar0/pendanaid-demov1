<?php
  $no=1;
  foreach ($dataProduk->result() as $produk) {
    // $tamp=$produk->gambar_ecommerce;
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $produk->judul; ?></td>
      <td>
        <div class="break-word">
          <?php echo substr($produk->deskripsi, 0,50) ?>..
        </div>
      </td>
      <td><?php echo $produk->jumlah_investasi; ?></td>
      
      <?php if ($produk->status_approve == 'refuse'){ ?>
        <td>Refuse</td>
      <?php }elseif($produk->status_approve == 'approve'){ ?>
        <td>Approve</td>
      <?php }elseif($produk->status_approve == 'pending'){ ?>
        <td>Pending</td>
      <?php } ?>
      
      <td class="text-center" style="min-width:270px;">
		<a href="<?php echo base_url() ?>Produk/update/<?php echo $produk->id_produk ?>">
          
          <button class="btn btn-warning">
            <input type="hidden" name="id_produk" value="<?php echo $produk->id_produk ?>">
            <i class="glyphicon glyphicon-repeat"></i> Update
          </button>
        </a>
		<?php
		if($produk->jum>0){
		?>
		<a href="<?php echo base_url() ?>Produk/history/<?php echo $produk->id_produk ?>" class="btn btn-success">
			<i class="fa fa-history"></i> History
		</a>
		<?php 
		}else{
		?>
        
        
          <button class="btn btn-danger konfirmasiHapus-produk" data-id="<?php echo $produk->id_produk; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Delete</button>
        <?php
		}
		?>
      </td>
    </tr>
    <?php
    $no++;
  }
?>
