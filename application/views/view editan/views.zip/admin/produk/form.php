<div class="content-wrapper">
  <div class=" col-md-12 well">
    <div class="form-msg"></div>
    <h3 style="display:block; text-align:center;">Tambah Data Produk</h3>

    <form method="POST" enctype="multipart/form-data" class="form-horizontal" action="<?php echo base_url() ?>Produk/prosesTambah">
      
      <div class="box-body">
		
        <!-- Site Url -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Site Url</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Site Url" name="siteurl" aria-describedby="sizing-addon2">
          </div>
        </div>

        <!-- Judul -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Judul</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Judul" name="judul" aria-describedby="sizing-addon2">
          </div>
        </div>

        <!-- Deskripsi -->
        <!-- <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Deskripsi</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Deskripsi" name="deskripsi" aria-describedby="sizing-addon2" >
          </div>
        </div> -->

        <!-- Jumlah Investasi -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Jumlah Investasi</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Jumlah Investasi" name="jumlah_investasi" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Slot -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Slot</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Slot" name="slot" aria-describedby="sizing-addon2" >
          </div>
        </div>  

        <!-- Bagi Hasil -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Bagi Hasil</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Bagi Hasil" name="bagi_hasil" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Minimal Pendanaan -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Minimal Pendanaan</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Minimal Pendanaan" name="minimal_pendanaan" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Agunan -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Agunan</label>

          <div class="col-sm-10">
            <select name="agunan" class="form-control " aria-describedby="sizing-addon2">
              <option disabled selected="">Nama Agunan</option>
              <option value="ada">Ada</option>
              <option value="tidak ada">Tidak Ada</option>
            </select>
          </div>
        </div>

        <!-- Tenor -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Tenor</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Tenor" name="tenor" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Pengembalian Pokok -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Pengembalian Pokok</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Pengembalian Pokok" name="pengembalian_pokok" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Frekuensi Angsuran -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Frekuensi Angsuran</label>

          <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Frekuensi Angsuran" name="frekuensi_angsuran" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Tanggal Awal -->
        <div class="form-group">
          <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Awal</label>

          <div class="col-sm-10">
            <input type="date" class="form-control" placeholder="Tanggal Awal" name="tglawal" aria-describedby="sizing-addon2" >
          </div>
        </div>

        <!-- Tanggal Akhir -->        <div class="form-group">          <label for="inputEmail3" class="col-sm-2 control-label">Tanggal Akhir</label>          <div class="col-sm-10">            <input type="date" class="form-control" placeholder="Tanggal Akhir" name="tglakhir" aria-describedby="sizing-addon2" >          </div>        </div>

        <!-- Foto -->
        <div class="form-group">
          <label for="inputPassword3" class="col-sm-2 control-label">Foto</label>

          <div class="col-sm-10">
            <input type="file" class="form-control" placeholder="Foto" name="foto" aria-describedby="sizing-addon2">
          </div>
        </div>

        <!-- Deskripsi -->
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Deskripsi</label>
            <div class="col-sm-10">
                  <textarea id="editor1" name="deskripsi" rows="10" cols="80" placeholder="Deskripsi"></textarea>
            </div>
        </div>

        <!-- Info Usaha -->
        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">Info Usaha</label>
            <div class="col-sm-10">
                  <textarea id="editor2" name="info_usaha" rows="10" cols="80" placeholder="Info Usaha"></textarea>
            </div>
        </div>

      </div>

      <div class="form-group">
        <div class="col-md-3">
          
        </div>

        <div class="col-md-3">
            <button type="submit" class="form-control btn btn-primary"> <i class="glyphicon glyphicon-ok"></i> Tambah Data</button>
        </div>
        
        <div class="col-md-3">
          <a href="<?php echo base_url() ?>Produk" class="form-control btn btn-danger">
            <i class="glyphicon glyphicon-remove"></i> Kembali
          </a>
        </div>
        
        <div class="col-md-3">
          
        </div>

      </div>
    </form>
    
  </div>
</div>

<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1',{
      // filebrowserUploadUrl: '<?php echo base_url() ?>Quiz/upload?type=Files&CKEditorFuncNum=2',
      // extraPlugins: 'uploadwidget,uploadimage,filebrowser'

      filebrowserImageUploadUrl : '<?php echo base_url(); ?>Produk/upload?type=image&path=page'
    })

    CKEDITOR.replace('editor2',{
      // filebrowserUploadUrl: '<?php echo base_url() ?>Quiz/upload?type=Files&CKEditorFuncNum=2',
      // extraPlugins: 'uploadwidget,uploadimage,filebrowser'

      filebrowserImageUploadUrl : '<?php echo base_url(); ?>Produk/upload?type=image&path=page'
    })
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>