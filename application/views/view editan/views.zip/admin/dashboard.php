<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel admin</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <h1>
        Welcome To Invest admin
        
      </h1>
      

    </section>
    <!-- /.content -->
  </div>
  <script src="<?php echo base_url(); ?>assets/admin/dist/js/pages/dashboard.js"></script>