<?php
//date_default_timezone_set("Asia/Jakarta");
setlocale(LC_ALL, 'id_ID.utf8');

$whd=array(
	"i.id_pengguna"=>$this->session->userdata("invest_pengguna"),
	"MONTH(p.tglakhir)"=>date("m"),
	"YEAR(p.tglakhir)"=>date("Y")
); 
if($this->input->post("periode")!=""){
	$exp=explode("-",$this->input->post("periode"));
	$whd["YEAR(p.tglakhir)"]=$exp[0];
	$whd["MONTH(p.tglakhir)"]=$exp[1];
}
$danadtl=$this->m_invest->dataDanaInvest($whd);
?>
<section id="team" >
    <div class="container"  >
        <div class="section">
            <div class="row mt-5">
                <div class="col-12" align="center">
                    <h4 class="text-left"><b>Proyeksi bagi hasil laba bulanan</b></h4>
                </div>
				<!-- <div class="col-12" align="center">
                    <embed name="E" id="E" src="<?php echo base_url() ?>assets/img/ico-report.svg" width="100px" height="100px">
                </div> -->
            </div>
			<div class="row mt-5">
				<div class="col-12">
					<form class="form-inline row" action="<?php echo base_url(); ?>investor/proyeksi" method="post">
						<label class="col-1 mr-1" for="periode">Periode</label>
						<select class="col-2 form-control" name="periode" id="periode" onchange="this.form.submit()">
							<?php
							$dateStart = (date("Y")-1)."-01-01";
							$endYear=(date("Y"))."-12-01";
							$dateEnd = date("Y-m-t", strtotime($endYear));
							$current_date = $dateStart;
							$now=date("Y-m");
							while(strtotime($current_date) < strtotime($dateEnd)){
								//echo $current_date."<br>";
								$mc=date("m", strtotime($current_date));
								$yc=date("Y", strtotime($current_date));
								$whd=array(
									"i.id_pengguna"=>$this->session->userdata("invest_pengguna"),
									"MONTH(p.tglakhir)"=>$mc,
									"YEAR(p.tglakhir)"=>$yc
								); 
								$danap=$this->m_invest->dataDanaInvest($whd);
								$yes=$danap->num_rows()>0?"yes":"";
								$dateny=date("Y-m", strtotime($current_date));
								$dateny2=strftime('%B %Y', strtotime($current_date));
								$sel="";
								if($this->input->post("periode")==""){
									$sel=$dateny==$now?"selected":"";
								} else {
									$sel=$dateny==$this->input->post("periode")?"selected":"";
								}
								?>
								<option class="<?php echo $yes; ?>" value="<?php echo $dateny; ?>" <?php echo $sel; ?>><?php echo $dateny2; ?></option>
								<?php
								$current_date= date("Y-m-d",strtotime("+1 month",strtotime($current_date)));
							} 
							?>
						</select>
						<?php
						if($danadtl->num_rows()>0){
							?>
							<input id="export" type="button" class=" ml-3 col-2 btn btn-primary" value="Export" />
							<?php
						}
						?>
					</form>
				</div>
				
				<table class="mt-3 table table-bordered ">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Nama Kampanye</th>
							<th scope="col">Jumlah Investasi</th>
							<th scope="col">Bagi Hasil</th>
							<th scope="col">Jumlah Pengembalian</th>
							<th scope="col">Tanggal Berakhir</th>
							<th scope="col">Status</th>
						</tr>
					</thead>
					<?php
					if($danadtl->num_rows()>0){
					?>
					<tbody>
						<?php
						$num=0;
						$t1=0;
						$t2=0;
						foreach($danadtl->result() as $par){
							$num++;
							$t1=$t1+$par->jumlah_dana;
							$kembali = $par->jumlah_dana+(($par->jumlah_dana*$par->bagi_hasil)/100);
							$t2=$t2+$kembali;
							?>
							<tr>
							<td><?php echo $num; ?></td>
							<td><a href="<?php echo base_url()?>invest/detail/<?php echo $par->siteurl; ?>"><?php echo $par->judul; ?></a></td>
							
							<td class="text-right">Rp. <?php echo number_format($par->jumlah_dana,0,",","."); ?></td>
							<td><?php echo $par->bagi_hasil; ?>%</td>
							<td class="text-right">Rp. <?php echo number_format($kembali,0,",","."); ?></td>
							<td><?php echo date('d F Y', strtotime($par->tglakhir)); ?></td>
							<td><?php echo $par->status_approve; ?></td>
						</tr>
							<?php
						}
						?>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="2">Total</td>
							<td class="text-right">Rp. <?php echo number_format($t1,0,",","."); ?></td>
							<td>&nbsp;</td>
							<td class="text-right">Rp. <?php echo number_format($t2,0,",","."); ?></td>
							<td colspan="2">&nbsp;</td>
						</tr>
					</tfoot>
					<?php
					} else {
						?>
						<tbody>
							<tr>
								<td colspan="7" class="text-center">Data tidak ditemukan</td>
							</tr>
						</tbody>
						<?php
					}
					?>
				</table>
			</div>
		</div>
    </div>
</section>
<form id="formpdf" action="<?php echo base_url(); ?>invest/pdfproyeksi" method="post">
	
</form>
<script>
	$(document).ready(function(){
		$("#export").on("click",function(){
			$('#formpdf').html("");
			var periode=$("#periode option:selected").val();
			$('<input>').attr({
				type: 'hidden',
				id: 'periodepdf',
				name: 'periode',
				value:periode
			}).appendTo($('#formpdf'));
			$('#formpdf').submit();
			/* 
			$.post("<?php echo base_url(); ?>invest/pdfproyeksi", {periode:periode},function(result){
				//alert(result);
			}); */
		});
	});
</script>