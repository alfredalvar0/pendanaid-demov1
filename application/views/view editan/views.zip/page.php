<section id="team" >
    <div class="container"  >
        <div class="section">
            <div class="row mt-5">
                <div class="col-12">
                    <h3><?php echo $data_page->judul; ?></h3>
                </div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<?php echo $data_page->content; ?>
						</div>
					</div>
					
				</div>
            </div>
        </div>
    </div>
</section>