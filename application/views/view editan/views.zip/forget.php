 <br><br><br>
    
    <!--==========================
       Login Section
    ============================-->
    
    

    <section id="team">
      <div class="container">
        <div class="section-header">
          <h3>Lupa Password Akun Investasi</h3>
        </div>
        
        <div class="row wow fadeInUp">
        <div class="col-md-3"></div>
        <div class="col-md-6">    
            <div class="form">
              
              <form action="<?php echo base_url() ?>invest/kirimEmailnya" method="post" role="form" class="contactFormx">
                <div class="form-row">
                   
                  <div class="form-group col-lg-12 inner-addon left-addon">
                    <i class="fa fa-user"></i>
                     <input type="text" class="form-control" name="email" id="email" placeholder="Alamat Email" data-rule="email" data-msg="Please enter a valid email" />
                  </div>
                </div>
                
                <div class="text-center">
                    <div class="row">
                        <div class="col-md-3">&nbsp;</div>
                        <div class="col-md-6">
                            <button class="btn btn-lg btn-warning btn-block" type="submit" >Kirim</button>
                        </div>
                        <div class="col-md-3">&nbsp;</div>
                    </div>
                    
                </div>
                <div style="text-align:center">
                    <br><br>
                    Belum punya akun?  <a href="<?php echo base_url() ?>invest/register">Daftar sekarang</a>
                  
                </div>
              </form>
            </div>
            

        </div>
        <div class="col-md-3"></div>
        </div>
      </div>
    </section><!-- #team -->
    