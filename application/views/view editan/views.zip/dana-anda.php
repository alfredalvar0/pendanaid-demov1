<?php
$dtdana=$dana->num_rows()>0?$dana->row():0;
$wh=array("id_pengguna"=>$this->session->userdata("invest_pengguna"));
$dtbank = $this->m_invest->dataBank($wh);
?>
<br>
<!--==========================
   Home Section
============================-->
<section id="team" >
    <section style="background-color: rgb(214, 134, 44);">
        <div class="container" >
            <div class="section-header">
                <div class="row">
                    <div class="col-12">
                        <h3 style="color:white;text-align: justify;" class="mt-3 mb-0">Dana SevenPilar</h3>
						<p style="color:white;text-align: justify;" class="m-0 p-0">Dana saat ini :</p>
						<h4 style="color:white;text-align: justify;" class="m-0">Rp. <?php echo $dana->num_rows()>0?number_format($dtdana->jumlahdana,0,".","."):0; ?></h4>
						<p style="color:white;text-align: justify;" class="m-0 pb-4">Termasuk dana promo dan referral sebesar Rp. <?php echo $dana->num_rows()>0?number_format($dtdana->jumpnr,0,".","."):0; ?></p>
						<div class="row pb-5">
							<div class="col-6">
								<div class="text" style="position:absolute;">
									<button type="button" class="activate btn" style="background-color:#fdda0a">Tambah Dana</button>
								</div>
							</div>
							<div class="col-6">
								<?php
								if($dtbank->num_rows()>0 && ($dtbank->row()->nama_akun!="" && $dtbank->row()->no_rek!="" && $dtbank->row()->bank!="")){
									?>
									<div class="poptarik" style="position:absolute;">
										<button type="button" class="tarik btn" style="background-color:#fdda0a">Tarik Dana</button>
									</div>
									<?php
								} else {
									?>
									<a href="<?php echo base_url(); ?>investor/bank_account" class="btn btn-primary">Input User Bank</a>
									<?php
								}
								?>
							</div>
						</div>
						<div class="row pb-4">
							<div class="col-6">
								<p class="m-0 p-0" style="color:white;text-align: justify;">Total tambah dana</p>
								<p class="m-0 p-0" style="color:white;text-align: justify;">Rp. <?php echo $dana->num_rows()>0?number_format($dtdana->jumtambah,0,".","."):0; ?></p>
							</div>
							<div class="col-6">
								<p class="m-0 p-0" style="color:white;text-align: justify;">Total tarik dana</p>
								<p class="m-0 p-0" style="color:white;text-align: justify;">Rp. <?php echo $dana->num_rows()>0?number_format($dtdana->jumtarik,0,".","."):0; ?></p>
							</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h4 class="text-left mt-4"><b>History Transaksi</b></h4>
			</div>
			<?php 
			if($dana->num_rows()>0){
			?>
			<div class="col-12">
				<table class="table">
					<thead>
						<tr>
							<th scope="col">#</th>
							<th scope="col">Type</th>
							<th scope="col">Jumlah</th>
							<th scope="col">Status</th>
							<th scope="col">Tanggal</th>
							
						</tr>
					</thead>
					<tbody>
						<?php
						$num=0;
						foreach($danadtl->result() as $dt){
							$num++;
							?>
							<tr>
								<td><?php echo $num; ?></td>
								<td><?php echo $dt->type_dana; ?></td>
								<td>Rp. <?php echo number_format($dt->jumlah_dana,0,".","."); ?></td>
								<td><?php echo $dt->status_approve; ?></td>
								<td><?php echo $dt->createddate; ?></td>
							</tr>
							<?php
						}
						?>
					</tbody>
				</table>
			</div>
			<?php
			} else {
			?>
			<div class="col-12 text-center">
				<embed name="E" id="E" src="<?php echo base_url() ?>assets/img/ico-wallet.svg" width="100px" height="100px">
				<p class="text-center">Anda belum melakukan transaksi</p>
			</div>
			<?php
			}
			?>
		</div>
	</div>
</section><!-- #team -->
<script>
$(document).ready(function(){
	$('.activate').click(function () {
		$('.close-btn').click(function(){
			$('.tooltip').animate({ opacity: 0 }, 330, function(){
				$(this).remove();
			});
		});
		$('.tooltip').animate({ opacity: 0 }, 330, function(){
			$(this).remove();
		});
		
		$('.text').showToolTip({
			title: 'Tambah Dana',
			position:"right",
			content: '<div class="row"><input class="col-12 form-control" type="number" id="jumlah_donasi" min="1000000" max="999999999" /></div><div class="row"><a href="javascript:;" class="btn tooltip-btn col-6" style="border:2px solid #fdda0a;">Batal</a><a href="javascript:;" id="pay" class="btn col-6" style="margin:10px 0;border:2px solid #fdda0a;background-color:#fdda0a;">Tambah Dana</a></div>',
			onApprove: function(){
				console.log('OK is clicked!');
				/* $('.tooltip').animate({ opacity: 0 }, 330, function(){
					$(this).remove();
				}); */
			}
		});
		//$('.tooltip').css({ top: '50%', marginTop: -'10px', left: '100%' }).animate({ left: '150px', opacity: 1 });
		$(".tooltip-action").hide();
		$('#jumlah_donasi').focus();
		$('#jumlah_donasi').keyup(function () {
			var thisvalue=$(this).val();
			if(parseInt(thisvalue)>=999999999){
				$(this).val(999999999);
			}
		});
		$('#pay').click(function (event) {
			event.preventDefault();
			payment("tambahdana","Tambah Dana"); 
		});
	});
	
	$('.tarik').click(function () {
		$('.close-btn').click(function(){
			$('.tooltip').animate({ opacity: 0 }, 330, function(){
				$(this).remove();
			});
		});
		$('.tooltip').animate({ opacity: 0 }, 330, function(){
			$(this).remove();
		});
		
		$('.poptarik').showToolTip({
			title: 'Tarik Dana',
			position:"bottom",
			content: '<div class="row">'+
				'<label class="control-label">Jumlah Dana</label>'+
				'<input class="col-12 form-control" type="number" id="jumlah_tarik" min="100000" max="<?php echo intval($this->session->userdata("invest_dana")); ?>" />'+
				'<label class="control-label passus">Password</label>'+
				'<input class="col-12 form-control passus" type="password" id="passuser" />'+
			'</div>'+
			'<div class="row">'+
				'<a href="javascript:;" class="btn tooltip-btn col-6" style="border:2px solid #fdda0a;">Batal</a>'+
				'<a href="javascript:;" id="btntarik" class="btn col-6" style="margin:10px 0; border:2px solid #fdda0a; background-color:#fdda0a;">Tarik Dana</a>'+
			'</div>',
			onApprove: function(){
				console.log('OK is clicked!');
				/* $('.tooltip').animate({ opacity: 0 }, 330, function(){
					$(this).remove();
				}); */
			}
		});
		<?php
		$arr=array("fb","google");
		if(in_array($this->session->userdata("invest_login"),$arr)){
			?>
			$(".passus").hide();
			<?php
		}
		?>
		//$('.tooltip').css({ top: '50%', marginTop: -'10px', left: '100%' }).animate({ left: '150px', opacity: 1 });
		$(".tooltip-action").hide();
		$('#jumlah_tarik').focus();
		$('#jumlah_tarik').keyup(function () {
			var thisvalue=$(this).val();
			if(parseInt(thisvalue)>=<?php echo intval($this->session->userdata("invest_dana")); ?>){
				$(this).val(<?php echo intval($this->session->userdata("invest_dana")); ?>);
			}
		});
		$('#btntarik').click(function (event) {
			event.preventDefault();
			tarikdana(); 
		});
	});
});
function tarikdana(){
	var jum = $("#jumlah_tarik").val();
	if(parseInt(jum)>=100000 && parseInt(jum)<=<?php echo intval($this->session->userdata("invest_dana")); ?>){
		// tarik
		var passw=$("#passuser").val();
		$.ajax({
			url: '<?=site_url()?>invest/tarikDana', //calling this function
			data:{pass:passw,jumlah_tarik:jum},
			type:'POST',
			cache: false,
			dataType:"json",
			success: function(data) {
				if(data.result){
					//alert("sukses");
					location.reload();
				} else {
					alert("Password Salah");
					$("#passuser").val("");
					$("#passuser").focus();
				}
			}
		});
	} else {
		if(parseInt(jum)<100000 || parseInt(jum)><?php echo intval($this->session->userdata("invest_dana")); ?>){
			if(parseInt(jum)><?php echo intval($this->session->userdata("invest_dana")); ?>){
				alert("Penarikan Tidak bisa lebih dari <?php echo $this->session->userdata("invest_dana"); ?>");
			} else {
				alert("Minimal penarikan dana 100ribu");
			}
		}else{
			alert("Masukkan Jumlah Penarikan");
		}
		$('#jumlah_tarik').focus();
	}
}
function payment(act,title){
  //$(this).attr("disabled", "disabled");
	var jum = $("#jumlah_donasi").val();
	if(parseInt(jum)>=1000000 && parseInt(jum)<=999999999){
		var action = act;
		var id_user = "<?php echo $this->session->userdata("invest_pengguna"); ?>";//$("#id_user").val();
		var phone = "<?php echo $this->session->userdata("invest_hp"); ?>";
		
		var val=jum.replace(/\./g, '');
		var id = "<?php echo rand(0,1000); ?>";//$("#id").val();
		var nama_program = title;//$("#nama_program").val();
		var email = "<?php echo $this->session->userdata("invest_email"); ?>";//$("#email").val();
		var firstname = "<?php echo $this->session->userdata("invest_username"); ?>";//$("#firstname").val();
		var ucapan_dukungan = "-";//$("#ucapan_dukungan").val();
		/* if($('#ckb').is(':checked')){
		firstname='Anonim';
		} */
		if(email!="" && jum!="" && val.length >= 5 && isEmail(email)==true){
			$.ajax({
				url: '<?=site_url()?>invest/proses_payment', //calling this function
				data:{id_user:id_user,jumlah_donasi:jum,id:id,nama_program:nama_program,email:email,firstname:firstname,ucapan_dukungan:ucapan_dukungan,phone:phone,action:action},
				type:'POST',
				cache: false,
				success: function(data) {
					// alert(data);
					//alert(data);
					// location.reload(data);
					window.location.href = data;
				}
			});
		}else{
			if(val.length < 5){
				alert("nominal tidak boleh kurang dari 10.000");
			}else if(email==""){
				alert("email harus di isi");
			}else if(isEmail(email)==false){
				alert("alamat email tidak sesuai");
			}
		}
	} else {
		if(parseInt(jum)<1000000 || parseInt(jum)>999999999){
			if(parseInt(jum)>999999999){
				alert("Input Tidak boleh lebih dari 999999999");
			} else {
				alert("Minimal pengisian Dana 1jt");
			}
		}else{
			alert("Masukkan Jumlah Dana");
		}
	}
}
function isEmail(email) {
	var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	return regex.test(email);
}
</script>