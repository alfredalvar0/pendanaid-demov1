<?php
$wh = array("kategori"=>"perhatian","status_delete"=>"0");
$dataPerhatian = $this->m_invest->getPage($wh);
$wh = array("modul"=>"whatsapp");
$datawhatsapp = $this->m_invest->refferal_setting($wh)->row();
$datalink = $this->m_invest->getLink();
$wh = array(
	"kategori"=>"footer",
	"status_delete"=>"0"
);
$datafooter = $this->m_invest->getPage($wh);
$wh2 = array(
	"kategori"=>"footer2",
	"status_delete"=>"0"
);
$datafooter2 = $this->m_invest->getPage($wh2);

$wh = array("kategori"=>"perhatian","status_delete"=>"0");
$dataPerhatian = $this->m_invest->getPage($wh);
?>
<!--==========================
Footer
============================-->
<footer id="footer">
    <div class="footer-top">
        <div class="_container">
            <div class="row pl-5" style="width:100%">
            
                <div class="col-lg-2 col-md-2 footer-info">
                    <a href="<?php echo base_url() ?>" style="font-size:27px;">SEVENPILAR</a>
                    <div class="social-links">
                        <?php
                        foreach($datalink->result() as $dtl){
                            ?>
                            <a class="mb-2" href="<?php echo $dtl->nama_link; ?>"><i class="fa <?php echo $dtl->icon ?>"></i></a>
                            <?php
                        }
                        ?>
                        
                        <!-- <a href="javascript:;" class="twitter"><i class="fa fa-twitter"></i></a>
                        <a href="javascript:;" class="facebook"><i class="fa fa-facebook"></i></a>
                        <a href="javascript:;" class="instagram"><i class="fa fa-instagram"></i></a>
                        <a href="javascript:;" class="google-plus"><i class="fa fa-google-plus"></i></a>
                        <a href="javascript:;" class="linkedin"><i class="fa fa-linkedin"></i></a> -->
                    </div>
					<!-- <img src="<?php echo base_url(); ?>assets/img/playstore.png" width="150px" height="50px">&nbsp;<img src="<?php echo base_url(); ?>assets/img/appstore.png" width="150px" height="50px"> -->
                </div>
                <div class="col-lg-6 col-md-6 footer-links">
                    <div class="row">
                        <div class="col-12 footer-links">
                
                            <ul class="row">
                                <?php
                                /* $num=1;
                                for($i=0;$i<18;$i++){
                                    echo '<li><a href="javascript:;">'.$num.'</a></li>';
                                    if($num % 6 ==0){
                                        ?>
                                            </ul>
                                        </div>
                                        <div class="col-lg-2 col-md-6 footer-links">
                                            <ul>
                                        <?php
                                    }
                                    $num++;
                                } */
                                $num=1;
                                foreach($datafooter->result() as $dtf){
                                    if($dtf->judul =="") continue;
                                    echo '<li class="col-md-6"><a href="'.base_url().'invest/page/'.$dtf->link_page.'">'.$dtf->judul.'</a></li>';
                                    /* if($num % 6 ==0){
                                        ?>
                                            </ul>
                                        </div>
                                        <div class="col-4 footer-links">
                                            <ul>
                                        <?php
                                    } */
                                    $num++;
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
                
                
                <!-- <div class="col-lg-2 col-md-6 footer-links">
                
                <ul>
                <li><a href="javascript:;">Beri Pinjaman</a></li>
                <li><a href="javascript:;">Ajukan Pinjaman</a></li>
                <li><a href="javascript:;">Tentang Kami</a></li>
                <li><a href="javascript:;">Kalender Kegiatan Partnership</a></li>
                <li><a href="javascript:;">Hubungi Kami</a></li>
                <li><a href="javascript:;">FAQ</a></li>
                </ul>
                </div>
                
                <div class="col-lg-2 col-md-6 footer-links">
                <ul>
                <li><a href="javascript:;">Kalkulator Finansial</a></li>
                <li><a href="javascript:;">Risiko Pemberian Pinjaman</a></li>
                <li><a href="javascript:;">Risiko Penerima Pinjaman</a></li>
                <li><a href="javascript:;">Info Penilaian Risiko</a></li>
                <li><a href="javascript:;">Pinjaman UKM</a></li>
                </ul>
                </div>
                
                <div class="col-lg-3 col-md-6 footer-links">
                <ul>
                <li><a href="javascript:;">Kebijakan Auto Withdrawal untuk Dana Mengendap Lender</a></li>
                <li><a href="javascript:;">Ketentuan Kode Referral</a></li>
                <li><a href="javascript:;">Ketentuan Auto Landing</a></li>
                <li><a href="javascript:;">Ketentuan Layanan Pengaduan Pengguna</a></li>
                <li><a href="javascript:;">Draft Standar Perjanjian Pinjaman</a></li>
                <li><a href="javascript:;">Draft Standar Perjanjian Jual Beli dan Pengalihan Piutang</a></li>
                </ul>
                </div> -->
                
                <div class="col-lg-4 col-md-4 footer-links">
                    <img src="<?php echo base_url(); ?>assets/img/playstore.png" width="150px" height="50px">&nbsp;
					<!-- <img src="<?php echo base_url(); ?>assets/img/appstore.png" width="150px" height="50px"> -->
                </div>
                
                
            </div>
            
        </div>
    </div>
    
    <div class="container">
		<div class="row mt-5">
			<div class="col-md-12">
				<?php
				if($dataPerhatian->num_rows()>0){
					foreach($dataPerhatian->result() as $dt){
					?>
					<h3><?php echo $dt->judul; ?></h3>
					<?php echo $dt->content; ?>
					<?php
					}
				}
				?>
			</div>
		</div>
        <div class="row">
            <div class="col-md-6" style="font-size:16px;margin-top:20px">Copyright &copy; 2019 PT. SevenPilar All Right Reserved.</div>
            <div class="col-md-6 text-right" style="font-size:26px;margin-top:20px"> <!-- Kebijakan Privasi -->
                <?php
                foreach($datafooter2->result() as $dtf2){
                    echo '<a class="text-white" href="'.base_url().'invest/page/'.$dtf2->link_page.'">'.$dtf2->judul.'</a>';
                }
                ?>
            </div>
        </div>
		
    
    </div>
</footer><!-- #footer -->
<?php
$valwhatsapp = json_decode($datawhatsapp->value);
?>
<a class="whatsapp" href="https://web.whatsapp.com/send?phone=<?php echo $valwhatsapp->phone; ?>&amp;text=<?php echo $valwhatsapp->text; ?>" target="_blank"><i class="fa fa-whatsapp fa-2x mt-1"></i></a>
<a href="#top" class="back-to-top"><i class="fa fa-chevron-up"></i></a>