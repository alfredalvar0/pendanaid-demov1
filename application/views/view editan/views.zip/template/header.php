<?php
$wh = array("kategori"=>"header");
$dataheader = $this->m_invest->getPage($wh);
?>
<!--==========================
  Header
  ============================-->
  <header id="header" class="fixed-top" style="border-bottom:3px solid #999">
    <div class="container">

      <div class="logo float-left">
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <h1 class="text-light"><a href="#header"><span>NewBiz</span></a></h1> -->
		<a href="<?php echo base_url(); ?>"  >
		<img src="<?php echo base_url() ?>assets/img/investpro.png" />
        <label style="font-size:27px;color:white">Increase your finance</label></a>
      </div>

      <nav class="main-nav float-right d-none d-lg-block" style="padding-bottom:5px">
        <ul>
            <?php
                foreach($dataheader->result() as $dth){
					if($dth->judul!="Portofolio Saya"){
                    ?>
                    <li class=""><a href="<?php echo base_url() ?><?php echo $dth->link_page; ?>"><?php echo $dth->judul; ?></a></li>
                    <?php
					}
                }
            ?>
          <!-- <li class=""><a href="javascript:;">Jadilah Investor</a></li>
          <li class=""><a href="javascript:;">Ajukan Pinjaman</a></li>
          <li class=""><a href="javascript:;">Tentang Kami</a></li>
          <li class=""><a href="javascript:;">FAQ</a></li>
          -->
          
        
          
          <li class=""><a href="<?php echo base_url() ?>invest/login" class="btn btn-lg  btn-block" style="border:2px solid white;margin-right:5px">Masuk</a>&nbsp;</li>
          <li class=""><a href="<?php echo base_url() ?>invest/register" class="btn btn-lg btn-warning btn-block" style="border:2px solid #fdda0a;margin-left:5px;background-color:#fdda0a;color:black;">Daftar</a>&nbsp;</li>
          <li class=""><a href="javascript:;" style="font-size:30px;margin-top:-8px;color:#fdda0a"><i class="fa fa-user-circle"></i></a></li>
        </ul>
      </nav><!-- .main-nav -->
      
    </div>
    
  </header><!-- #header -->
