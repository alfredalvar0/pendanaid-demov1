<?php
$dataBanner = $this->m_invest->banner()->row();
$wh=array("status"=>"1");
$dataSlider = $this->m_invest->slider($wh);
$wh=array("status_approve"=>"approve");
$dataSumAllProduk = $this->m_invest->dataSumAllProduk($wh);
$danaTerkumpul = $this->m_invest->danaTerkumpul();
$keuntunganDibagikan = $this->m_invest->keuntunganDibagikan();
$wh = array("kategori"=>"perhatian","status_delete"=>"0");
$dataPerhatian = $this->m_invest->getPage($wh);
?>
<style>
    .dropdown-check-list{
    display: inline-block;
    width: 100%;
    }
    .dropdown-check-list:focus{
    outline:0;
    }
    .dropdown-check-list .anchor {
    width: 98%;
    position: relative;
    cursor: pointer;
    display: inline-block;
    padding-top:5px;
    padding-left:5px;
    padding-bottom:5px;
    border:1px #ccc solid;
    }
    .dropdown-check-list .anchor:after {
    position: absolute;
    content: "";
    border-left: 2px solid black;
    border-top: 2px solid black;
    padding: 5px;
    right: 10px;
    top: 20%;
    -moz-transform: rotate(-135deg);
    -ms-transform: rotate(-135deg);
    -o-transform: rotate(-135deg);
    -webkit-transform: rotate(-135deg);
    transform: rotate(-135deg);
    }
    .dropdown-check-list .anchor:active:after {
    right: 8px;
    top: 21%;
    }
    .dropdown-check-list ul.items {
    padding: 2px;
    display: none;
    margin: 0;
    border: 1px solid #ccc;
    border-top: none;
    }
    .dropdown-check-list ul.items li {
    list-style: none;
    }
    .dropdown-check-list.visible .anchor {
    color: #0094ff;
    }
    .dropdown-check-list.visible .items {
    display: block;
    }
</style>

<script>
jQuery(function ($) {
        var checkList = $('.dropdown-check-list');
        checkList.on('click', 'span.anchor', function(event){
            var element = $(this).parent();

            if ( element.hasClass('visible') )
            {
                element.removeClass('visible');
            }
            else
            {
                element.addClass('visible');
            }
        });
    });
</script>

<br>
<!--==========================
   Home Section style="background-color: rgb(214, 134, 44);"
============================-->
<section id="team" >
    <section >
    	<!-- <div class="container"> -->
    		<!-- Slider -->
	        <!-- <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
			  <ol class="carousel-indicators">
			    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
			  </ol>
			  <div class="carousel-inner">
			    <div class="carousel-item active">
			      <img class="d-block w-100" src="<?php echo base_url() ?>assets/img/bg-home.png" style="background-position: right 50px;background-repeat:no-repeat;background-size: 300px; " alt="First slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" src="<?php echo base_url() ?>assets/img/bg-home.png" style="background-position: right 50px;background-repeat:no-repeat;background-size: 300px;" alt="Second slide">
			    </div>
			    <div class="carousel-item">
			      <img class="d-block w-100" src="https://investpro.mynimstudio.id/assets/img/produk/resto_korea.jpg" style="background-position: right 50px; background-repeat:no-repeat;background-size: 100px;" alt="Third slide">
			    </div>
			  </div>
			  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </a>
			  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			    <span class="carousel-control-next-icon" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </a>
			</div>
	    </div> -->
	    <!-- Ending Slider style="background-position: right 50px;background-repeat:no-repeat;background-image: url('<?php echo base_url() ?>assets/img/bg-home.png');background-size: 300px;" -->
    	<!-- </div> -->

        <div class="container" >
            
            	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            		<div class="section-header">
	            		<ol class="carousel-indicators">
						    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active" style="background-color: black"></li>
						    <li data-target="#carouselExampleIndicators" data-slide-to="1" style="background-color: black"></li>
						 </ol>
						<div class="carousel-inner">
							<?php
							$nums=0;
							foreach($dataSlider->result() as $sl){
								?>
								<div class="carousel-item <?php echo $nums==0?"active":""; ?>" alt="slide" style="background-image:url('<?php echo base_url() ?>/assets/img/slider/<?php echo $sl->image_slider; ?>');background-size: contain;background-repeat: no-repeat;background-position: right;">
									<div class="row">
										
										<div class="col-md-9">
											<h4 class="pt-5" style="text-align:left;color:black;"><?php
												echo $sl->title_slider;
											?></h4>
										</div>
									</div>
									<div class="row">
										

										<div class="col-md-9">
											<h6 style="text-align:justify;color:black;text-shadow: 1px 1px grey;"><?php
												echo $sl->desc_slider;
											?></h6>
										</div>
									</div>
								</div>
								<?php
								$nums++;
							} 
							?>
							<!-- <div class="carousel-item active" alt="First slide">
			            		<div class="row">
				                    
				                    <div class="col-md-9">
				                        <h3 class="pt-5" style="text-align:left;color:black;">Biarkan uang yang bekerja untuk Anda dan kembangkan keuangan Anda dalam industry properti yang simple, untung dan aman</h3>
				                    </div>
				                </div>
				                <div class="row">
				                    

				                    <div class="col-md-9">
				                        <h5 style="text-align:justify;color:black;">Berikan pinjaman kepada pelakudan dapatkan imbal hasil rata-rata 18%-24% per tahun. Lebih dari 98% nilai portfolio pinjaman memiliki agunan dan proses pemberian pinjaman berbasis online.</h5>
				                    </div>
				                </div>
			            	</div>

			            	<div class="carousel-item " alt="Second slide">
			            		<div class="row">
				                    <div class="col-md-9">
				                        <h3 class="pt-5" style="text-align:left;color:black;">Pinjaman usaha fleksibel, sesuai kebutuhan</h3>
				                    </div>
				                </div>
				                <div class="row">
				                    <div class="col-md-9">
				                        <h5 style="text-align:justify;color:black;">Ajukan pinjaman sesuai dengan kebutuhan unik usaha kamu. Kami dapat menyesuaikan besar pinjaman, tenor pinjaman, agunan, dan frekuensi pembayaran cicilan.</h5>
				                    </div>
				                </div>
			            	</div> -->
			                
			                <!-- <div class="row pb-2">
			                    <div class="col-3">
			                        <button type="button" class="btn btn-lg  btn-block" style="borderborder:2px solid #fdda0a;margin-left:5px;background-color:#fdda0a;" >Setup Auto Lending</button>
			                    </div>
			                    <div class="col-9 text-right">
			                        <a href="javascript:;" style="color:white;"><u>Lihat Cara Memberikan Pinjaman ></u></a>
			                    </div>
			                </div> -->
		            	</div>	
		            	<br><br>
			            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev" >
					    	<span class="carousel-control-prev-icon" aria-hidden="true" ></span>
					    	<span class="sr-only" >Previous</span>
					  	</a>
					  	<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
					    	<span class="carousel-control-next-icon" aria-hidden="true"></span>
					    	<span class="sr-only">Next</span>
					  	</a>
					</div>
            	</div>

            
        </div>
    </section>
    <div class="container mt-5" >
        <div class="row">
            <div class="col-12">
                <h3><b>Kampanye Pinjaman yang Sedang Berlangsung</b></h3>
            </div>
        </div>
		<form action="<?php echo base_url(); ?>" method="post">
			<div class="row">
				<div class="col-md-2">
					<!--<h6>Tipe Kampanye <i class="fa fa-chevron-down"></i></h6>-->
					<div id="list3" class="dropdown-check-list">
						<span class="anchor">Tipe Kampanye </span>
						<ul class="items">
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="kampanye" type="radio" value="all" checked /></td>
								<td>Lihat Semua</td>
								</tr>
								</table>
							</li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-2">
					<!--<h6>Lama Tenor <i class="fa fa-chevron-down"></i></h6>-->
					<div id="list3" class="dropdown-check-list">
						<span class="anchor">Lama Tenor </span>
						<ul class="items">
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="tenor" type="radio" value="all" checked /></td>
								<td>Lihat Semua</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="tenor" type="radio" value="lt6"/></td>
								<td><= 6 Bulan</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="tenor" type="radio" value="gt6"/></td>
								<td>> 6 Bulan</td>
								</tr>
								</table>
							</li>
						</ul>
					</div>
				</div>
				
				<div class="col-md-2">
					<!--<h6>Bunga Efektif <i class="fa fa-chevron-down"></i></h6>-->
					<div id="list3" class="dropdown-check-list">
						<span class="anchor">Bunga Efektif </span>
						<ul class="items">
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="bunga" type="radio" value="all" checked /></td>
								<td>Lihat Semua</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="bunga" type="radio" value="lt12"/></td>
								<td><= 12%</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="bunga" type="radio" value="gt12"/></td>
								<td>> 12 - 24%</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="bunga" type="radio" value="gt24"/></td>
								<td>> 24%</td>
								</tr>
								</table>
							</li>
						</ul>
					</div>
				</div>
				
				<!-- <div class="col-md-2">-->
					<!--<h6>Agunan <i class="fa fa-chevron-down"></i></h6>-->
				<!--	<div id="list3" class="dropdown-check-list">-->
				<!--		<span class="anchor">Agunan </span>-->
				<!--		<ul class="items">-->
				<!--			<li><table width="100%"><tr>-->
				<!--				<td width="15%"><input class="rf" name="agunan" type="radio" value="all" checked /></td>-->
				<!--				<td>Lihat Semua</td>-->
				<!--				</tr>-->
				<!--				</table>-->
				<!--			</li>-->
				<!--			<li><table width="100%"><tr>-->
				<!--				<td width="15%"><input class="rf" name="agunan" type="radio" value="Ada"/></td>-->
				<!--				<td>Beragunan</td>-->
				<!--				</tr>-->
				<!--				</table>-->
				<!--			</li>-->
				<!--			<li><table width="100%"><tr>-->
				<!--				<td width="15%"><input class="rf" name="agunan" type="radio" value="Tidak"/></td>-->
				<!--				<td>Tanpa Agunan</td>-->
				<!--				</tr>-->
				<!--				</table>-->
				<!--			</li>-->
				<!--		</ul>-->
				<!--	</div>-->
				<!--</div>-->
				
				<div class="col-md-3">
					<!--<h6>Urutan <i class="fa fa-chevron-down"></i></h6>-->
					<div id="list3" class="dropdown-check-list">
						<span class="anchor">Urutan </span>
						<ul class="items">
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="all" checked /></td>
								<td>Lihat Semua</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="Oldest"/></td>
								<td>Kampanye Terlama</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="Newest"/></td>
								<td>Kampanye Terbaru</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="Smallest"/></td>
								<td>Pinjaman Terkecil</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="Biggest"/></td>
								<td>Pinjaman Terbesar</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="smallrose"/></td>
								<td>Bunga Terkecil</td>
								</tr>
								</table>
							</li>
							<li><table width="100%"><tr>
								<td width="15%"><input class="rf" name="urutan" type="radio" value="bigrose"/></td>
								<td>Bunga Terbesar</td>
								</tr>
								</table>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</form>
        <div class="row" id="list-data">
            <?php
			$datany['data_produk']=$data_produk;
            $this->load->view("list-data",$datany);
            
            ?>
        </div>
		<div class="row mt-5">
			<?php
			if($dataSumAllProduk->num_rows()>0){
				$dts=$dataSumAllProduk->row();
				foreach($dataSumAllProduk->result() as $dts){
					$rp="";
					$jum=$dts->jum;
					if($dts->title=="Dana Terkumpul"){
						$rp="Rp ";
						$jum=$this->m_invest->terbilang($dts->jum);
					}
					?>
					<div class="col-md-3 text-center">
						<h1><b><?php echo $rp.$jum; ?></b></h1>
						<p class="m-0 p-0"><?php echo $dts->title; ?></p>
					</div>
					<?php
				}
				$kumpul=0;
				foreach($danaTerkumpul->result() as $dtku){
					$kumpul=$kumpul+$dtku->jum;
				}
				$untung=0;
				foreach($keuntunganDibagikan->result() as $dtk){
					$untung=$untung+$dtk->jum;
				}
				?>
				<div class="col-md-3 text-center">
					<h1><b>Rp <?php echo $this->m_invest->terbilang($kumpul); ?></b></h1>
					<p class="m-0 p-0">Dana Terkumpul</p>
				</div>
				<div class="col-md-3 text-center">
					<h1><b>Rp <?php echo $this->m_invest->terbilang($untung); ?></b></h1>
					<p class="m-0 p-0">Keuntungan dibagikan</p>
				</div>
				<?php
			}
			?>
		</div>
		<div class="row mt-5">
			<div class="col-md-4 text-center">&nbsp;</div>
			<div class="col-md-4 text-center">
			<?php 
			$angka = 1530093765765;
			//echo $this->m_invest->terbilang($angka);
			?>
				Memberikan kemudahaan dan aksesibilitas bagi setiap orang untuk bisa berinvestasi pada properti dengan menggunakan teknologi.
			</div>
			<div class="col-md-4 text-center">&nbsp;</div>
		</div>
		<!--
		Sample <a href="https://web.whatsapp.com/send?phone=+6289699935552&amp;text=Salam Kenal Mas Nuris, Saya Ingin Diskusi" onclick="gtag('event', 'WhatsApp', {'event_action': 'whatsapp_chat', 'event_category': 'Chat', 'event_label': 'Chat_WhatsApp'});" target="_blank">Konsultasi Via Whatapps</a>
		-->
		
        <div class="row mt-5">
            <div class="col-md-6">
				<?php
				$ext = $this->m_invest->get_file_extension($dataBanner->image_banner);
				if($ext=="svg"){
				?>
                <embed name="E" id="E" src="<?php echo base_url() ?>assets/img/banner/<?php echo $dataBanner->image_banner; ?>" width="100%">
				<?php
				} else {
				?>
				<img src="<?php echo base_url() ?>assets/img/banner/<?php echo $dataBanner->image_banner; ?>" width="100%" />
				<?php
				}
				?>
            </div>
            <div class="col-md-6">
                <h3><?php echo $dataBanner->title_banner; ?></h3>
                <h5><?php echo $dataBanner->desc_banner; ?></h5>
            </div>
        </div>
		<!-- <div class="row mt-5">
			<div class="col-md-12">
				<?php
				if($dataPerhatian->num_rows()>0){
					foreach($dataPerhatian->result() as $dt){
					?>
					<h3><?php echo $dt->judul; ?></h3>
					<?php echo $dt->content; ?>
					<?php
					}
				}
				?>
			</div>
		</div> -->
    </div>
</section><!-- #team -->
<?php

?>
<script>
	$(document).ready(function(){
		$(".rf").change(function(){
			filternya();
		});
	});
	function filternya(){
		var n=0;
		var nilai = {};
		var fi=["kampanye","tenor","bunga","urutan"];
		$(".rf:checked").each(function(){
			var tv = $(this).val();
			nilai[fi[n]]=tv;
			//console.log("val"+n+"->"+tv);
			n++;
		});
		console.log(nilai);
		$.ajax({
			url: "<?php echo base_url(); ?>invest/indexfilter", 
			data : nilai,
			type:"post",
			dataType:"html",
			success: function(result){
				$("#list-data").html(result);
			}
		});
	}
</script>