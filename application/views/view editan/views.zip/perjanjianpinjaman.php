<section id="team" >
    <div class="container"  >
        <div class="section">
            <div class="row mt-5">
                <div class="col-12" align="center">
                    <h4 class="text-left"><b>Perjanjian Anggota</b></h4>
                </div>
				<div class="col-12">
					<div class="card">
						<div class="card-body">
							<iframe src="<?php echo base_url()."investor/pdf_perjanjianpinjaman";?>" width="100%" height="600px"></iframe>
						</div>
					</div>
					
				</div>
            </div>
        </div>
    </div>
</section>

