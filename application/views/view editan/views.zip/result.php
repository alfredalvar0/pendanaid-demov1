<br><br><br>
    
    <!--==========================
       Register Section
    ============================-->
    <section id="team">
        <div class="container">
            <div class="section-header" align="center">
				<img src="<?php echo base_url(); ?>assets/img/sip.png">
                <h3><?php echo $this->session->flashdata("msg"); ?></h3>
				<p class="text-center">Terima kasih telah melengkapi data Anda. Kami akan melakukan verifikasi dalam waktu paling lambat 1x24 jam. Setelah diverifikasi dan menandatangani surat perjanjian secara digital, Anda baru bisa mulai memberikan pinjaman. </p>
            </div>
        </div>
    </section>