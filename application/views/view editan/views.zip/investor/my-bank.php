<?php
$data = "";
if($data_bank->num_rows()>0){
	$data=$data_bank->row();
}
?>
<section id="team" >
    <div class="container"  >
        <div class="section">
            <div class="row mt-5">
                <div class="col-12" align="center">
					<div class="card" >
						<div class="card-header text-left">
							<!-- <a href="<?php echo base_url(); ?>investor/add_bank" class="btn btn-primary"><i class="fa fa-plus"></i></a> -->
							<h4>Data Bank</h4>
						</div>
						<div class="card-body">
							<form action="<?php echo base_url(); ?>investor/proses_edit_bank" method="post">
								<input type="hidden" name="id_pengguna" value="<?php echo $data!=""?$data->id_pengguna:""; ?>" />
								<div class="form-group row">
									<label class="control-label col-md-2 text-left" for="bank">Bank</label>
									<select class="form-control col-md-10" name="bank" id="bank">
										<option selected disabled>-- Pilih Bank --</option>
										<?php 
										foreach($mbank->result() as $dtb){
											echo '<option value="'.$dtb->id_bank.'" '.($dtb->id_bank==$data->bank?"selected":"").'>'.$dtb->nama_bank.'</option>';
										}
										?>
									</select>
								</div>
								<div class="form-group row">
									<label class="control-label col-md-2 text-left" for="akun_bank">Nama Akun Bank</label>
									<input type="text" id="akun_bank" class="form-control col-md-10" name="nama_akun" value="<?php echo $data!=""?$data->nama_akun:""; ?>" />
								</div>
								<div class="form-group row">
									<label class="control-label col-md-2 text-left" for="norek">No. Rek</label>
									<input type="text" class="form-control col-md-10" id="norek" name="no_rek" value="<?php echo $data!=""?$data->no_rek:""; ?>" />
								</div>
								<button type="submit" class="btn btn-primary">Submit</button>
							</form>
							<!--
							<table class="table">
								<thead>
									<tr>
										<th scope="col">#</th>
										<th scope="col">Bank</th>
										<th scope="col">Nama Akun Bank</th>
										<th scope="col">No. Rek</th>
										<th scope="col">Aksi</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$num=0;
									foreach($data_bank->result() as $bank){
										$num++;
										$bankn="";
										if($bank->bank==1){
											$bankn="BCA";
										} else if($bank->bank==2){
											$bankn="Mandiri";
										} else if($bank->bank==3){
											$bankn="BRI";
										}
										?>
										<tr>
											<td><?php echo $num; ?></td>
											<td><?php echo $bankn; ?></td>
											<td><?php echo $bank->nama_akun; ?></td>
											<td><?php echo $bank->no_rek; ?></td>
											<td>
												<a href="<?php echo base_url(); ?>investor/edit_bank/<?php echo $bank->id_bank_pengguna ?>" class="btn btn-secondary"><i class="fa fa-pencil"></i></a>
												<a href="<?php echo base_url(); ?>investor/delete_bank/<?php echo $bank->id_bank_pengguna ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
											</td>
										</tr>
										<?php
										
									}
									?>
								</tbody>
							</table>
							-->
							
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php

?>